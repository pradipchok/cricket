<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Dashboard Screen
Route::get('/','HomeController@index');    

//Player controller
Route::resource('player', 'PlayerController');

//Team controller
Route::resource('team', 'TeamController');

//Match controller
Route::get('/points', 'MatchController@points')->name('match.points');
Route::resource('match', 'MatchController');
