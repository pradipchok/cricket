<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12 mt-3">
            <div class="card">
                <div class="card-header"><h3 class="card-title">Points Table</h3></div>
                <div class="card-body">
                   


                    <div class="card-body p-0">
                        
                        <table class="table table-condensed">
                          <thead>
                            <tr>
                                <th> Logo </th>
                                <th> Team  </th>                                
                                <th> W </th>
                                <th> L </th>
                                <th> Pts </th>
                            </tr>
                          </thead>
                          <tbody>
                                <?php if($teams->count()): ?>
                                <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                            
                                <tr>
                                    <td style="width: 100px"><img src="<?php echo e(asset('uploads/team')."/".$team->logoUri); ?>" alt="" style="width:100px" /></td>
                                    <td>
                                        <a href="<?php echo e(route('team.show',$team->id)); ?>" target="_blank" title="Show <?php echo e($team->name); ?>"><?php echo e($team->name); ?></a></td>                                  
                                    <td>                                    
                                        <?php echo e($match->wining($team->id)); ?>

                                    </td>
                                    <td>                                    
                                        <?php echo e($match->losing($team->id)); ?>

                                    </td>
                                    <td>                                    
                                        <?php echo e($match->wining($team->id)); ?> 
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                                <?php else: ?>
                                    <tr><td colspan="4"><div class="alert alert-danger">No data found.</div></td></tr>
                                <?php endif; ?>                      
                            </tbody>
                        </table>
                         <?php if($teams->count()): ?>
                        <div class="text-left">
                            <?php echo $teams->links(); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cricket\resources\views/match/points.blade.php ENDPATH**/ ?>