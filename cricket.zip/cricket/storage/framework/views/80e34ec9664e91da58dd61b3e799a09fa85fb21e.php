<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12 mt-3">
            <!-- BEGIN VALIDATION STATES-->
            <div class="card" id="form_wizard_1">
            	<div class="card-header"><h3>Add New Match</h3></div>                
                <?php if(count($errors) > 0): ?>
				<div class="alert alert-danger">
					<ul>
						<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><?php echo e($error); ?></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
				</div>
				<?php endif; ?>
                <div class="card-body mt-2">
                    <!-- BEGIN FORM-->

                      <form action="<?php echo e(route('match.update',$match->id)); ?>" id="form_sample_1" class="form-horizontal" method="POST" enctype="multipart/form-data">
						<?php echo e(csrf_field()); ?>

						<?php echo e(method_field('PUT')); ?>

						<div class="form-body">							
							<div class="form-group">
								<label class="control-label col-md-3">Wining Team <span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<select  name="winingTeamId" class="form-control <?php echo e($errors->has('winingTeamId') ? ' is-invalid' : ''); ?>">
										<option value="">--Please Select--</option>
										<?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($team->id); ?>" <?php echo e(($team->id==old('winingTeamId',$match->winingTeamId))?'selected':''); ?>>	
												<?php echo e($team->name); ?>

										</option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
							</div>

							<div class="form-group">
								<label class="control-label col-md-3">Losing Team <span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<select  name="losingTeamId" class="form-control <?php echo e($errors->has('losingTeamId') ? ' is-invalid' : ''); ?>">
										<option value="">--Please Select--</option>
										<?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($team->id); ?>" <?php echo e(($team->id==old('losingTeamId',$match->losingTeamId))?'selected':''); ?>>	
												<?php echo e($team->name); ?>

										</option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
							</div>

							
						</div>
						<div class="form-actions">
							<div class="row">
								<div class="col-md-offset-3 col-md-9 mt-1">
									<button type="submit" class="btn btn-primary">Submit</button>
									
									<a href="<?php echo e(route('match.index')); ?>" class="btn btn-warning">Cancel</a>
									
								</div>
							</div>
						</div>
					</form>
                    <!-- END FORM-->
                </div>
            </div>
            <!-- END VALIDATION STATES-->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cricket\resources\views/match/edit.blade.php ENDPATH**/ ?>