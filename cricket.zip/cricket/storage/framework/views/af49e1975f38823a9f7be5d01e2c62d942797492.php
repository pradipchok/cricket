<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12 mt-3">
            <!-- BEGIN VALIDATION STATES-->
            <div class="card" id="form_wizard_1">
            	<div class="card-header"><h3>Add New Team</h3></div>                
                <?php if(count($errors) > 0): ?>
				<div class="alert alert-danger">
					<ul>
						<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><?php echo e($error); ?></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
				</div>
				<?php endif; ?>
                <div class="card-body mt-2">
                    <!-- BEGIN FORM-->

                      <form action="<?php echo e(route('team.store')); ?>" id="form_sample_1" class="form-horizontal" method="POST" enctype="multipart/form-data">
						<?php echo e(csrf_field()); ?>

						<div class="form-body">
							
							<div class="form-group">
								<label class="control-label col-md-3"> Name
								<span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<input type="text" name="name" class="form-control <?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" placeholder="Name" value="<?php echo e(old('name')); ?>" required/>
								</div>
							</div>
							
							<div class="form-group">
								<label class="control-label col-md-3">Club State
								<span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<input type="text" name="clubState" class="form-control <?php echo e($errors->has('clubState') ? ' is-invalid' : ''); ?>" placeholder="Club State" value="<?php echo e(old('clubState')); ?>" required/>
								</div>
							</div>
							
							<div class="form-group">
								<label class="control-label col-md-3">Logo
								<span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<input type="file" name="logoUri" class="form-control" />
								</div>
							</div>
							
							<div class="form-group">
								<label class="control-label col-md-3">Players <span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<select multiple="multiple"  name="playerId[]" class="form-control <?php echo e($errors->has('playerId') ? ' is-invalid' : ''); ?>">										
										<?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($player->id); ?>" <?php echo e((in_array($player->id,old('playerId',[])))?'selected':''); ?>>	
												<?php echo e($player->lastName); ?> <?php echo e($player->firstName); ?>

										</option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
							</div>			
						</div>
						<div class="form-actions">
							<div class="row">
								<div class="col-md-offset-3 col-md-9 mt-1">
									<button type="submit" class="btn btn-primary">Submit</button>
									
									<a href="<?php echo e(route('team.index')); ?>" class="btn btn-warning">Cancel</a>
									
								</div>
							</div>
						</div>
					</form>
                    <!-- END FORM-->
                </div>
            </div>
            <!-- END VALIDATION STATES-->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cricket\resources\views/team/create.blade.php ENDPATH**/ ?>