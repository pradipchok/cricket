<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12 mt-3">
            <!-- BEGIN VALIDATION STATES-->
            <div class="card" id="form_wizard_1">
            	<div class="card-header"><h3>Add New Player</h3></div>                
                <?php if(count($errors) > 0): ?>
				<div class="alert alert-danger">
					<ul>
						<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><?php echo e($error); ?></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
				</div>
				<?php endif; ?>
                <div class="card-body mt-2">
                    <!-- BEGIN FORM-->

                      <form action="<?php echo e(route('player.store')); ?>" id="form_sample_1" class="form-horizontal" method="POST" enctype="multipart/form-data">
						<?php echo e(csrf_field()); ?>

						<div class="form-body">
							
							<div class="form-group">
								<label class="control-label col-md-3">First  Name
								<span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<input type="text" name="firstName" class="form-control <?php echo e($errors->has('firstName') ? ' is-invalid' : ''); ?>" placeholder="First Name" value="<?php echo e(old('firstName')); ?>" required/>
								</div>
							</div>
							
							<div class="form-group">
								<label class="control-label col-md-3">Last  Name
								<span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<input type="text" name="lastName" class="form-control <?php echo e($errors->has('lastName') ? ' is-invalid' : ''); ?>" placeholder="Last Name" value="<?php echo e(old('lastName')); ?>" required/>
								</div>
							</div>

							<div class="form-group">
								<label class="control-label col-md-3">Player Jersey Number
								<span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<input type="number" name="playerJerseyNumber" class="form-control <?php echo e($errors->has('playerJerseyNumber') ? ' is-invalid' : ''); ?>" placeholder="Player Jersey Number" value="<?php echo e(old('playerJerseyNumber')); ?>" required/>
								</div>
							</div>

							<div class="form-group">
								<label class="control-label col-md-3">Image
								<span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<input type="file" name="imageUri" class="form-control" />
								</div>
							</div>
							
							<div class="form-group">
								<label class="control-label col-md-3">Country <span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<select  name="country" class="form-control <?php echo e($errors->has('country') ? ' is-invalid' : ''); ?>">
										<option value="">--Please Select--</option>
										<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($country->countryName); ?>" <?php echo e(($country->countryName==old('country'))?'selected':''); ?>>	
												<?php echo e($country->countryName); ?>

										</option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
							</div>

							<div class="form-group">
								<label class="control-label col-md-3">Player History <span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<textarea name="playerHistory" class="form-control <?php echo e($errors->has('playerHistory') ? ' is-invalid' : ''); ?>" placeholder="Player History"><?php echo e(old('playerHistory')); ?></textarea>
								</div>
							</div>
						</div>
						<div class="form-actions">
							<div class="row">
								<div class="col-md-offset-3 col-md-9 mt-1">
									<button type="submit" class="btn btn-primary">Submit</button>
									
									<a href="<?php echo e(route('player.index')); ?>" class="btn btn-warning">Cancel</a>
									
								</div>
							</div>
						</div>
					</form>
                    <!-- END FORM-->
                </div>
            </div>
            <!-- END VALIDATION STATES-->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cricket\resources\views/player/create.blade.php ENDPATH**/ ?>