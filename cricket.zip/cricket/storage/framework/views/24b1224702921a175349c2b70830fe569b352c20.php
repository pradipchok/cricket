<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12 mt-3">
            <div class="card">
                <div class="card-header"><h3 class="card-title">Manage Team </h3></div>
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?> 
                    <?php if(session('error')): ?>
                        <div class="alert alert-warning" role="alert">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?> 

                    <div class="card-body p-0">
                        <div class="btn-group">
                              <a href="<?php echo e(route('team.create')); ?>">  <button id="sample_editable_1_new" class="btn green"> Add New
                                    <i class="fa fa-plus"></i>
                                </button></a>                                
                        </div>
                        <hr/>
                        <table class="table table-condensed">
                          <thead>
                            <tr>
                                <th> Logo </th>
                                <th> Name </th>                                
                                <th> Action </th>
                            </tr>
                          </thead>
                          <tbody>
                                <?php if($teams->count()): ?>
                                <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                            
                                <tr>
                                    <td><img src="<?php echo e(asset('uploads/team')."/".$team->logoUri); ?>" alt="" style="width:100px" /></td>
                                    <td>
                                        <a href="<?php echo e(route('team.show',$team->id)); ?>" target="_blank" title="Show <?php echo e($team->name); ?>"><?php echo e($team->name); ?></a></td>                                  
                                    <td>                                    
                                        <a href="<?php echo e(route('team.edit',$team->id)); ?>" class="btn btn-outline btn-circle green btn-sm purple" title="Edit"><i class="fa fa-edit"></i></a>

                                        <a href="javascript:void(0);"  onclick="event.preventDefault();if(confirm('Do you want to delete?')){document.getElementById('logout-form-<?php echo e($team->id); ?>').submit();}" class="btn btn-outline btn-circle dark btn-sm red" title="Delete">
                                            <i class="fa fa-trash"></i>   </a>
                                         <form id="logout-form-<?php echo e($team->id); ?>" action="<?php echo e(route('team.destroy',$team->id)); ?>" method="POST" style="display: none;">
                                           <?php echo e(csrf_field()); ?>

                                           <?php echo e(method_field('DELETE')); ?>

                                         </form>
                                        
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                                <?php else: ?>
                                    <tr><td colspan="4"><div class="alert alert-danger">No data found.</div></td></tr>
                                <?php endif; ?>                      
                            </tbody>
                        </table>
                         <?php if($teams->count()): ?>
                        <div class="text-left">
                            <?php echo $teams->links(); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cricket\resources\views/team/index.blade.php ENDPATH**/ ?>