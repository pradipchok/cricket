<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12 mt-3">
            <div class="card">
                <div class="card-header"><h3 class="card-title"><?php echo e($team->name); ?></h3></div>
                <div class="card-body">
                    <table class="table table-condensed">
                          <thead>
                            <tr>
                                <th> Image </th>
                                <th> Last Name </th>
                                <th> First Name </th>
                                <th> Player Jersey Number </th>
                                <th> Country </th>
                                <th> Player History </th>
                            </tr>
                          </thead>
                          <tbody>
                               
                                <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                            
                                <tr>
                                    <td><img src="<?php echo e(asset('uploads/player')."/".$player->imageUri); ?>" alt="" style="width:100px" /></td>
                                    <td><?php echo e($player->lastName); ?></td>
                                    <td><?php echo e($player->firstName); ?></td>
                                    <td><?php echo e($player->playerJerseyNumber); ?></td>
                                    <td><?php echo e($player->country); ?></td>
                                    <td><?php echo e($player->playerHistory); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                                                     
                            </tbody>
                        </table>

                    
                </div>
            </div>
        </div>
    </div>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cricket\resources\views/team/show.blade.php ENDPATH**/ ?>