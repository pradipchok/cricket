@extends('layouts.master')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12 mt-3">
            <!-- BEGIN VALIDATION STATES-->
            <div class="card" id="form_wizard_1">
            	<div class="card-header"><h3>Edit Player</h3></div>                
                @if(count($errors) > 0)
				<div class="alert alert-danger">
					<ul>
						@foreach($errors->all() as $error)
							<li>{{$error}}</li>
						@endforeach
					</ul>
				</div>
				@endif
                <div class="card-body mt-2">
                    <!-- BEGIN FORM-->

                      <form action="{{route('player.update',$player->id)}}" id="form_sample_1" class="form-horizontal" method="POST" enctype="multipart/form-data">
						{{csrf_field()}}
						{{method_field('PUT')}}
						<div class="form-body">
							
							<div class="form-group">
								<label class="control-label col-md-3">First  Name
								<span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<input type="text" name="firstName" class="form-control" placeholder="First Name" value="{{old('firstName',$player->firstName)}}" required/>
								</div>
							</div>
							
							<div class="form-group">
								<label class="control-label col-md-3">Last  Name
								<span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<input type="text" name="lastName" class="form-control" placeholder="Last Name" value="{{old('lastName',$player->lastName)}}" required/>
								</div>
							</div>

							<div class="form-group">
								<label class="control-label col-md-3">Player Jersey Number
								<span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<input type="number" name="playerJerseyNumber" class="form-control" placeholder="Player Jersey Number" value="{{old('playerJerseyNumber',$player->playerJerseyNumber)}}" required/>
								</div>
							</div>

							<div class="form-group">
								<label class="control-label col-md-3">Image
								<span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<input type="file" name="imageUri" class="form-control" />
									<br/>
									<img src="{{asset('uploads/player')."/".$player->imageUri}}" alt="" style="width:100px" />
								</div>
							</div>
							
							<div class="form-group">
								<label class="control-label col-md-3">Country <span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<select  name="country" class="form-control">
										<option value="">--Please Select--</option>
										@foreach($countries as $country)
										<option value="{{$country->countryName}}" {{($country->countryName==old('country',$player->country))?'selected':''}}>	
												{{$country->countryName}}
										</option>
										@endforeach
									</select>
								</div>
							</div>

							<div class="form-group">
								<label class="control-label col-md-3">Player History <span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<textarea name="playerHistory" class="form-control" placeholder="Player History">{{old('playerHistory',$player->playerHistory)}}</textarea>
								</div>
							</div>
						</div>
						<div class="form-actions">
							<div class="row">
								<div class="col-md-offset-3 col-md-9 mt-1">
									<button type="submit" class="btn btn-primary">Submit</button>
									
									<a href="{{route('player.index')}}" class="btn btn-warning">Cancel</a>
									
								</div>
							</div>
						</div>
					</form>
                    <!-- END FORM-->
                </div>
            </div>
            <!-- END VALIDATION STATES-->
        </div>
    </div>
</div>
@endsection