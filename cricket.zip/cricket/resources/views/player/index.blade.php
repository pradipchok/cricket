@extends('layouts.master')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12 mt-3">
            <div class="card">
                <div class="card-header"><h3 class="card-title">Manage Players </h3></div>
                <div class="card-body">
                    @if (session('success'))
                        <div class="alert alert-success" role="alert">
                            {{ session('success') }}
                        </div>
                    @endif 
                     @if (session('error'))
                        <div class="alert alert-warning" role="alert">
                            {{ session('error') }}
                        </div>
                    @endif 


                    <div class="card-body p-0">
                        <div class="btn-group">
                              <a href="{{route('player.create')}}">  <button id="sample_editable_1_new" class="btn green"> Add New
                                    <i class="fa fa-plus"></i>
                                </button></a>                                
                        </div>
                        <hr/>
                        <table class="table table-condensed">
                          <thead>
                            <tr>
                                <th> Image </th>
                                <th> Last Name </th>
                                <th> First Name </th>
                                <th> Action </th>
                            </tr>
                          </thead>
                          <tbody>
                                @if($players->count())
                                @foreach($players as $player)                            
                                <tr>
                                    <td><img src="{{asset('uploads/player')."/".$player->imageUri}}" alt="" style="width:100px" /></td>
                                    <td>{{$player->lastName}}</td>
                                    <td>{{$player->firstName}}</td>
                                    <td>                                    
                                        <a href="{{route('player.edit',$player->id)}}" class="btn btn-outline btn-circle green btn-sm purple" title="Edit"><i class="fa fa-edit"></i></a>

                                        <a href="javascript:void(0);"  onclick="event.preventDefault();if(confirm('Do you want to delete?')){document.getElementById('logout-form-{{$player->id}}').submit();}" class="btn btn-outline btn-circle dark btn-sm red" title="Delete">
                                            <i class="fa fa-trash"></i>   </a>
                                         <form id="logout-form-{{$player->id}}" action="{{route('player.destroy',$player->id)}}" method="POST" style="display: none;">
                                           {{ csrf_field() }}
                                           {{method_field('DELETE')}}
                                         </form>
                                        
                                    </td>
                                </tr>
                                @endforeach     
                                @else
                                    <tr><td colspan="4"><div class="alert alert-danger">No data found.</div></td></tr>
                                @endif                      
                            </tbody>
                        </table>
                         @if($players->count())
                        <div class="text-left">
                            {!! $players->links() !!}
                        </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>    
@endsection