@extends('layouts.master')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12 mt-3">
            <!-- BEGIN VALIDATION STATES-->
            <div class="card" id="form_wizard_1">
            	<div class="card-header"><h3>Add New Player</h3></div>                
                @if(count($errors) > 0)
				<div class="alert alert-danger">
					<ul>
						@foreach($errors->all() as $error)
							<li>{{$error}}</li>
						@endforeach
					</ul>
				</div>
				@endif
                <div class="card-body mt-2">
                    <!-- BEGIN FORM-->

                      <form action="{{route('player.store')}}" id="form_sample_1" class="form-horizontal" method="POST" enctype="multipart/form-data">
						{{csrf_field()}}
						<div class="form-body">
							
							<div class="form-group">
								<label class="control-label col-md-3">First  Name
								<span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<input type="text" name="firstName" class="form-control {{ $errors->has('firstName') ? ' is-invalid' : '' }}" placeholder="First Name" value="{{old('firstName')}}" required/>
								</div>
							</div>
							
							<div class="form-group">
								<label class="control-label col-md-3">Last  Name
								<span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<input type="text" name="lastName" class="form-control {{ $errors->has('lastName') ? ' is-invalid' : '' }}" placeholder="Last Name" value="{{old('lastName')}}" required/>
								</div>
							</div>

							<div class="form-group">
								<label class="control-label col-md-3">Player Jersey Number
								<span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<input type="number" name="playerJerseyNumber" class="form-control {{ $errors->has('playerJerseyNumber') ? ' is-invalid' : '' }}" placeholder="Player Jersey Number" value="{{old('playerJerseyNumber')}}" required/>
								</div>
							</div>

							<div class="form-group">
								<label class="control-label col-md-3">Image
								<span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<input type="file" name="imageUri" class="form-control" />
								</div>
							</div>
							
							<div class="form-group">
								<label class="control-label col-md-3">Country <span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<select  name="country" class="form-control {{ $errors->has('country') ? ' is-invalid' : '' }}">
										<option value="">--Please Select--</option>
										@foreach($countries as $country)
										<option value="{{$country->countryName}}" {{($country->countryName==old('country'))?'selected':''}}>	
												{{$country->countryName}}
										</option>
										@endforeach
									</select>
								</div>
							</div>

							<div class="form-group">
								<label class="control-label col-md-3">Player History <span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<textarea name="playerHistory" class="form-control {{ $errors->has('playerHistory') ? ' is-invalid' : '' }}" placeholder="Player History">{{old('playerHistory')}}</textarea>
								</div>
							</div>
						</div>
						<div class="form-actions">
							<div class="row">
								<div class="col-md-offset-3 col-md-9 mt-1">
									<button type="submit" class="btn btn-primary">Submit</button>
									
									<a href="{{route('player.index')}}" class="btn btn-warning">Cancel</a>
									
								</div>
							</div>
						</div>
					</form>
                    <!-- END FORM-->
                </div>
            </div>
            <!-- END VALIDATION STATES-->
        </div>
    </div>
</div>
@endsection