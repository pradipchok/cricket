@extends('layouts.master')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12 mt-3">
            <div class="card">
                <div class="card-header"><h3 class="card-title">Points Table</h3></div>
                <div class="card-body">
                   


                    <div class="card-body p-0">
                        
                        <table class="table table-condensed">
                          <thead>
                            <tr>
                                <th> Logo </th>
                                <th> Team  </th>                                
                                <th> W </th>
                                <th> L </th>
                                <th> Pts </th>
                            </tr>
                          </thead>
                          <tbody>
                                @if($teams->count())
                                @foreach($teams as $team)                            
                                <tr>
                                    <td style="width: 100px"><img src="{{asset('uploads/team')."/".$team->logoUri}}" alt="" style="width:100px" /></td>
                                    <td>
                                        <a href="{{route('team.show',$team->id)}}" target="_blank" title="Show {{$team->name}}">{{$team->name}}</a></td>                                  
                                    <td>                                    
                                        {{$match->wining($team->id)}}
                                    </td>
                                    <td>                                    
                                        {{$match->losing($team->id)}}
                                    </td>
                                    <td>                                    
                                        {{$match->wining($team->id)}} 
                                    </td>
                                </tr>
                                @endforeach     
                                @else
                                    <tr><td colspan="4"><div class="alert alert-danger">No data found.</div></td></tr>
                                @endif                      
                            </tbody>
                        </table>
                         @if($teams->count())
                        <div class="text-left">
                            {!! $teams->links() !!}
                        </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>    
@endsection