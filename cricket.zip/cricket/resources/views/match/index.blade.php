@extends('layouts.master')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12 mt-3">
            <div class="card">
                <div class="card-header"><h3 class="card-title">Manage Match </h3></div>
                <div class="card-body">
                    @if (session('success'))
                        <div class="alert alert-success" role="alert">
                            {{ session('success') }}
                        </div>
                    @endif 


                    <div class="card-body p-0">
                        <div class="btn-group">
                              <a href="{{route('match.create')}}">  <button id="sample_editable_1_new" class="btn green"> Add New
                                    <i class="fa fa-plus"></i>
                                </button></a>                                
                        </div>
                        <hr/>
                        <table class="table table-condensed">
                          <thead>
                            <tr>
                                <th> Wining Team </th>
                                <th> Losing Team </th>
                                <th> Action </th>
                            </tr>
                          </thead>
                          <tbody>
                                @if($matches->count())
                                @foreach($matches as $match)                            
                                <tr>                                    
                                    <td>{{$match->winingTeam->name}}</td>
                                    <td>{{$match->losingTeam->name}}</td>
                                    <td>                                    
                                        <a href="{{route('match.edit',$match->id)}}" class="btn btn-outline btn-circle green btn-sm purple" title="Edit"><i class="fa fa-edit"></i></a>

                                        <a href="javascript:void(0);"  onclick="event.preventDefault();if(confirm('Do you want to delete?')){document.getElementById('logout-form-{{$match->id}}').submit();}" class="btn btn-outline btn-circle dark btn-sm red" title="Delete">
                                            <i class="fa fa-trash"></i>   </a>
                                         <form id="logout-form-{{$match->id}}" action="{{route('match.destroy',$match->id)}}" method="POST" style="display: none;">
                                           {{ csrf_field() }}
                                           {{method_field('DELETE')}}
                                         </form>
                                        
                                    </td>
                                </tr>
                                @endforeach     
                                @else
                                    <tr><td colspan="4"><div class="alert alert-danger">No data found.</div></td></tr>
                                @endif                      
                            </tbody>
                        </table>
                         @if($matches->count())
                        <div class="text-left">
                            {!! $matches->links() !!}
                        </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>    
@endsection