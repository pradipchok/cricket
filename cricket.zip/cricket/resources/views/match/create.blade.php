@extends('layouts.master')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12 mt-3">
            <!-- BEGIN VALIDATION STATES-->
            <div class="card" id="form_wizard_1">
            	<div class="card-header"><h3>Add New Match</h3></div>                
                @if(count($errors) > 0)
				<div class="alert alert-danger">
					<ul>
						@foreach($errors->all() as $error)
							<li>{{$error}}</li>
						@endforeach
					</ul>
				</div>
				@endif
                <div class="card-body mt-2">
                    <!-- BEGIN FORM-->

                      <form action="{{route('match.store')}}" id="form_sample_1" class="form-horizontal" method="POST" enctype="multipart/form-data">
						{{csrf_field()}}
						<div class="form-body">							
							<div class="form-group">
								<label class="control-label col-md-3">Wining Team <span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<select  name="winingTeamId" class="form-control {{ $errors->has('winingTeamId') ? ' is-invalid' : '' }}">
										<option value="">--Please Select--</option>
										@foreach($teams as $team)
										<option value="{{$team->id}}" {{($team->id==old('winingTeamId'))?'selected':''}}>	
												{{$team->name}}
										</option>
										@endforeach
									</select>
								</div>
							</div>

							<div class="form-group">
								<label class="control-label col-md-3">Losing Team <span class="required" aria-required="true"> * </span></label>
								<div class="col-md-4">
									<select  name="losingTeamId" class="form-control {{ $errors->has('losingTeamId') ? ' is-invalid' : '' }}">
										<option value="">--Please Select--</option>
										@foreach($teams as $team)
										<option value="{{$team->id}}" {{($team->id==old('losingTeamId'))?'selected':''}}>	
												{{$team->name}}
										</option>
										@endforeach
									</select>
								</div>
							</div>

							
						</div>
						<div class="form-actions">
							<div class="row">
								<div class="col-md-offset-3 col-md-9 mt-1">
									<button type="submit" class="btn btn-primary">Submit</button>
									
									<a href="{{route('match.index')}}" class="btn btn-warning">Cancel</a>
									
								</div>
							</div>
						</div>
					</form>
                    <!-- END FORM-->
                </div>
            </div>
            <!-- END VALIDATION STATES-->
        </div>
    </div>
</div>
@endsection