@extends('layouts.master')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12 mt-3">
            <div class="card">
                <div class="card-header"><h3 class="card-title">{{$team->name}}</h3></div>
                <div class="card-body">
                    <table class="table table-condensed">
                          <thead>
                            <tr>
                                <th> Image </th>
                                <th> Last Name </th>
                                <th> First Name </th>
                                <th> Player Jersey Number </th>
                                <th> Country </th>
                                <th> Player History </th>
                            </tr>
                          </thead>
                          <tbody>
                               
                                @foreach($players as $player)                            
                                <tr>
                                    <td><img src="{{asset('uploads/player')."/".$player->imageUri}}" alt="" style="width:100px" /></td>
                                    <td>{{$player->lastName}}</td>
                                    <td>{{$player->firstName}}</td>
                                    <td>{{$player->playerJerseyNumber}}</td>
                                    <td>{{$player->country}}</td>
                                    <td>{{$player->playerHistory}}</td>
                                </tr>
                                @endforeach     
                                                     
                            </tbody>
                        </table>

                    
                </div>
            </div>
        </div>
    </div>
</div>    
@endsection