@extends('layouts.master')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12 mt-3">
            <div class="card">
                <div class="card-header"><h3 class="card-title">Manage Team </h3></div>
                <div class="card-body">
                    @if (session('success'))
                        <div class="alert alert-success" role="alert">
                            {{ session('success') }}
                        </div>
                    @endif 
                    @if (session('error'))
                        <div class="alert alert-warning" role="alert">
                            {{ session('error') }}
                        </div>
                    @endif 

                    <div class="card-body p-0">
                        <div class="btn-group">
                              <a href="{{route('team.create')}}">  <button id="sample_editable_1_new" class="btn green"> Add New
                                    <i class="fa fa-plus"></i>
                                </button></a>                                
                        </div>
                        <hr/>
                        <table class="table table-condensed">
                          <thead>
                            <tr>
                                <th> Logo </th>
                                <th> Name </th>                                
                                <th> Action </th>
                            </tr>
                          </thead>
                          <tbody>
                                @if($teams->count())
                                @foreach($teams as $team)                            
                                <tr>
                                    <td><img src="{{asset('uploads/team')."/".$team->logoUri}}" alt="" style="width:100px" /></td>
                                    <td>
                                        <a href="{{route('team.show',$team->id)}}" target="_blank" title="Show {{$team->name}}">{{$team->name}}</a></td>                                  
                                    <td>                                    
                                        <a href="{{route('team.edit',$team->id)}}" class="btn btn-outline btn-circle green btn-sm purple" title="Edit"><i class="fa fa-edit"></i></a>

                                        <a href="javascript:void(0);"  onclick="event.preventDefault();if(confirm('Do you want to delete?')){document.getElementById('logout-form-{{$team->id}}').submit();}" class="btn btn-outline btn-circle dark btn-sm red" title="Delete">
                                            <i class="fa fa-trash"></i>   </a>
                                         <form id="logout-form-{{$team->id}}" action="{{route('team.destroy',$team->id)}}" method="POST" style="display: none;">
                                           {{ csrf_field() }}
                                           {{method_field('DELETE')}}
                                         </form>
                                        
                                    </td>
                                </tr>
                                @endforeach     
                                @else
                                    <tr><td colspan="4"><div class="alert alert-danger">No data found.</div></td></tr>
                                @endif                      
                            </tbody>
                        </table>
                         @if($teams->count())
                        <div class="text-left">
                            {!! $teams->links() !!}
                        </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>    
@endsection