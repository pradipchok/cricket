<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Team extends Model
{
	use SoftDeletes;

    protected $fillable = ['id','name','logoUri','clubState','playerId'];
    
    protected $dates = ['deleted_at'];

    public function teamPlayers()
    {
        return $this->hasMany('App\TeamPlayers','teamId','id');
    }    
}
