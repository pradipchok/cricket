<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Match extends Model
{
    use SoftDeletes;

    protected $fillable = ['id','winingTeamId','losingTeamId'];
    
    protected $dates = ['deleted_at'];

    public function winingTeam()
    {
        return $this->hasOne('App\Team','id','winingTeamId');
    }   

    public function losingTeam()
    {
        return $this->hasOne('App\Team','id','losingTeamId');
    }  

    public function wining($id)
    {
        return $this->where('winingTeamId',$id)->count();
    }  

    public function losing($id)
    {
        return $this->where('losingTeamId',$id)->count();
    }
}
