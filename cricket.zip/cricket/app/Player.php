<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Player extends Model
{
	use SoftDeletes;

    protected $fillable = ['id','firstName','lastName','imageUri','playerJerseyNumber','country','playerHistory'];
    
    protected $dates = ['deleted_at'];
}
