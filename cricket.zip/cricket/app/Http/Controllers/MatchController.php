<?php

namespace App\Http\Controllers;
use App\Team;
use App\Match;
use Illuminate\Http\Request;
use Validator;
use Illuminate\Support\Facades\DB;

class MatchController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $matches=Match::orderBy('id','desc')->paginate(10);
        return view('match.index',compact('matches'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {       
       $teams=Team::orderBy('name')->get();    
       return view('match.create',compact('teams'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $validator = Validator::make($request->all(), [
            'winingTeamId' => 'required',
            'losingTeamId' => 'required',
        ]);

         $validator->after(function ($validator) use($request) {
            if ($request->input('winingTeamId')==$request->input('losingTeamId')) {
                $validator->errors()->add('losingTeamId', 'Please select proper team!');
            }
            
            $prevMatch=Match::where('winingTeamId',$request->input('winingTeamId'))
                        ->where('losingTeamId',$request->input('losingTeamId'));
            if ($prevMatch->count()) {
                $validator->errors()->add('winingTeamId', 'Combination already exist, please select different teams!');
            }
        });

        if ($validator->fails()) {
            return redirect('match/create')
                        ->withErrors($validator)
                        ->withInput();
        }


        $match = [
            'winingTeamId'    => $request->input('winingTeamId'),
            'losingTeamId'    => $request->input('losingTeamId')
        ];
       
        $Match=Match::create($match);
        session()->flash('success', ' Match added successfully.');
        return redirect()->route('match.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Match  $match
     * @return \Illuminate\Http\Response
     */
    public function show(Match $match)
    {
        return redirect()->route('match.index');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Match  $match
     * @return \Illuminate\Http\Response
     */
    public function edit(Match $match)
    {   
        $teams=Team::orderBy('name')->get(); 
        return view('match.edit',compact('match','teams'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Match  $match
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Match $match)
    {
        $validator = Validator::make($request->all(), [
            'winingTeamId' => 'required',
            'losingTeamId' => 'required',
        ]);

         $validator->after(function ($validator) use($request,$match) {
            if ($request->input('winingTeamId')==$request->input('losingTeamId')) {
                $validator->errors()->add('losingTeamId', 'Please select proper team!');
            }
            
            $prevMatch=Match::where('winingTeamId',$request->input('winingTeamId'))
                        ->where('losingTeamId',$request->input('losingTeamId'))
                        ->where('id','<>',$match->id);
            if ($prevMatch->count()) {
                $validator->errors()->add('winingTeamId', 'Combination already exist, please select different teams!');
            }
        });

        if ($validator->fails()) {
            return redirect('match/'.$match->id."/edit")
                        ->withErrors($validator)
                        ->withInput();
        }


        $match->winingTeamId=$request->input('winingTeamId');
        $match->losingTeamId=$request->input('losingTeamId');
        $match->save();

        session()->flash('success', ' Match updated successfully.');
        return redirect()->route('match.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Match  $match
     * @return \Illuminate\Http\Response
     */
    public function destroy(Match $match)
    {
        $match->delete();
        session()->flash('success', ' Match deleted successfully.'); 
        return redirect()->route('match.index');
    }

    public function points(Match $match)
    {
        $teams=Team::leftJoin('matches', 'teams.id', '=', 'matches.winingTeamId')
                ->select(array('teams.*', DB::raw('COUNT(matches.winingTeamId) as c')))
                ->where('matches.deleted_at' , null)
                ->groupBy('matches.winingTeamId')
                ->orderBy('c','desc')->paginate(10);
              
        return view('match.points',compact('teams','match'));
    }
}
