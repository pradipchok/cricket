<?php

namespace App\Http\Controllers;

use App\Player;
use App\Country;
use App\TeamPlayers;
use Illuminate\Http\Request;
use Validator;

class PlayerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    protected $countries;

    public function __construct(Country $country)
    {
        $this->countries = $country->orderBy('countryName')->get();
    }

    public function index()
    {
        $players=Player::orderBy('lastName')->orderBy('firstName')->paginate(10);
        return view('player.index',compact('players'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {        
        $countries=$this->countries;
        return view('player.create',compact('countries'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validation
         $this->validate($request, [
            'firstName'             => 'required',
            'lastName'              => 'required',
            'imageUri'              => ['required','image'],
            'playerJerseyNumber'    => 'required',
            'country'               => 'required',
            'playerHistory'         => 'required',
        ]);


        /*============== Image upload ================*/
        $path=public_path('uploads/player/');
        $imageName = time().'.'.$request->imageUri->getClientOriginalExtension();
        $request->imageUri->move($path, $imageName);

        $player = [
            'firstName'         => $request->input('firstName'),
            'lastName'          => $request->input('lastName'),
            'imageUri'          => $imageName,
            'playerJerseyNumber'=> $request->input('playerJerseyNumber'),
            'country'           => $request->input('country'),
            'playerHistory'     =>$request->input('playerHistory')
        ];
       
        $Player=Player::create($player);
        session()->flash('success', ' Player added successfully.');
        return redirect()->route('player.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Player  $player
     * @return \Illuminate\Http\Response
     */
    public function show(Player $player)
    {
        return redirect()->route('player.index');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Player  $player
     * @return \Illuminate\Http\Response
     */
    public function edit(Player $player)
    {
        $countries=$this->countries;       
        return view('player.edit',compact('countries','player'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Player  $player
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Player $player)
    {
        // Validation
         $this->validate($request, [
            'firstName'             => 'required',
            'lastName'              => 'required',            
            'playerJerseyNumber'    => 'required',
            'country'               => 'required',
            'playerHistory'         => 'required',
        ]);

         if($request->has('imageUri')){            

            @unlink(public_path('uploads/player/').$player->imageUri);
            /*============== Image upload ================*/
            $path=public_path('uploads/player/');
            $imageName = time().'.'.$request->imageUri->getClientOriginalExtension();
            $player->imageUri=$imageName;
            $request->imageUri->move($path, $imageName);    
         }

        $player->firstName   = $request->input('firstName');
        $player->lastName    = $request->input('lastName');
        $player->playerJerseyNumber = $request->input('playerJerseyNumber');
        $player->country = $request->input('country');
        $player->playerHistory = $request->input('playerHistory');
        $player->save();


        session()->flash('success', ' Player updated successfully.');
        return redirect()->route('player.index');
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Player  $player
     * @return \Illuminate\Http\Response
     */
    public function destroy(Player $player)
    {
        //validation if assign to team, delete not possible
        $team=TeamPlayers::where('playerId',$player->id);
        if($team->count()){
            session()->flash('error', 'Wrong delete, player assigned to team.'); 
            return redirect()->route('player.index');
        }

        @unlink(public_path('uploads/player/').$player->imageUri);
        $player->delete();
        session()->flash('success', ' Player deleted successfully.'); 
        return redirect()->route('player.index');
    }
}
