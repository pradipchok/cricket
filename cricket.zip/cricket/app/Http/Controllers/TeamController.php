<?php

namespace App\Http\Controllers;

use App\Team;
use App\Player;
use App\TeamPlayers;
use App\Match;
use Illuminate\Http\Request;

class TeamController extends Controller
{
    protected $player;

    public function __construct(Player $player)
    {
        $this->player = $player;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $teams=Team::orderBy('name')->paginate(10);
        return view('team.index',compact('teams'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $team_players=TeamPlayers::select('playerId')->get()->toArray();
        $players=$this->player->whereNotIn('id',$team_players)->get();        
        return view('team.create',compact('players'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validation
         $this->validate($request, [
            'name'             => 'required',
            'clubState'        => 'required',
            'logoUri'          => ['required','image'],
            'playerId'         => 'required',
        ]);


        /*============== Image upload ================*/
        $path=public_path('uploads/team/');
        $imageName = time().'.'.$request->logoUri->getClientOriginalExtension();
        $request->logoUri->move($path, $imageName);

        $team = [
            'name'         => $request->input('name'),
            'clubState'    => $request->input('clubState'),
            'logoUri'     => $imageName
        ];
       
        $Team=Team::create($team);
        $playerId=$request->input('playerId');
        foreach ($playerId as  $value) {
            $TeamPlayer = [
            'teamId'         => $Team->id,
            'playerId'    => $value
        ];
       
        $TeamPlayer=TeamPlayers::create($TeamPlayer);
            
        }
        session()->flash('success', ' Team added successfully.');
        return redirect()->route('team.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Team  $team
     * @return \Illuminate\Http\Response
     */
    public function show(Team $team)
    {
        $players=[];
        foreach($team->teamPlayers as $teamPlayers)
        {            
            array_push($players, Player::find($teamPlayers->playerId));
        }   
        return view('team.show',compact('players','team'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Team  $team
     * @return \Illuminate\Http\Response
     */
    public function edit(Team $team)
    {
        
        $team_players=TeamPlayers::select('playerId')->where('teamID','<>',$team->id)->get()->toArray();
        $players=$this->player->whereNotIn('id',$team_players)->get();  
        $selectedTeam=[];
        foreach($team->teamPlayers->toArray() as $val)
        {
            array_push($selectedTeam, $val['playerId']);
        }      
        
        return view('team.edit',compact('players','team','selectedTeam'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Team  $team
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Team $team)
    {
         // Validation
         $this->validate($request, [
            'name'             => 'required',
            'clubState'        => 'required',
            'logoUri'          => ['sometimes','nullable','image'],
            'playerId'         => 'required',
        ]);

        if($request->has('logoUri')){         

            @unlink(public_path('uploads/team/').$team->logoUri);
            /*============== Image upload ================*/
            $path=public_path('uploads/team/');
            $imageName = time().'.'.$request->logoUri->getClientOriginalExtension();
            $team->logoUri=$imageName;
            $request->logoUri->move($path, $imageName);
        }
       
        $team->name=$request->input('name');
        $team->clubState=$request->input('clubState');
        $team->save();
        
        $playerId=$request->input('playerId');
        foreach ($playerId as  $value) {
            $teamPlayer=TeamPlayers::where('teamId',$team->id)->where('playerId',$value);
            $teamPlayer->delete();

            $TeamPlayer = [
                'teamId'      => $team->id,
                'playerId'    => $value
            ];
       
            $TeamPlayer=TeamPlayers::create($TeamPlayer);
            
        }
        session()->flash('success', ' Team updated successfully.');
        return redirect()->route('team.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Team  $team
     * @return \Illuminate\Http\Response
     */
    public function destroy(Team $team)
    {
        $Match=Match::where('winingTeamId',$team->id)
                ->orwhere('losingTeamId',$team->id);
        if($Match->count()){
            session()->flash('error', 'Wrong delete, team assigned to match.'); 
            return redirect()->route('team.index');
        }


        @unlink(public_path('uploads/team/').$team->logoUri);

        TeamPlayers::where('teamId',$team->id)->delete();

        $team->delete();
        session()->flash('success', ' Team deleted successfully.'); 
        return redirect()->route('team.index');
    }
}
