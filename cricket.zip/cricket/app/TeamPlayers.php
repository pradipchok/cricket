<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TeamPlayers extends Model
{
     protected $fillable = ['id','teamId','playerId'];

    
}
